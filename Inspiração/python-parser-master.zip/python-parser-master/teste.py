def main():
    # aqui um comentario simples
    for a in "teste":
        a = a + 1
    if (a > x and x >= b):
        a = 2
        b = 3
    soma (a , b) 
    '''aqui eh comentario
       multiplo '''
    name = "Bruno"
    number = 7.5
    c = 3 + a	
    d += i
    recebeFunc = Function()
    exp = (14 * a - (a / c)))
    c = a + b
    if ( (a + b) > c or name == "Bruno"):
        c = a - b
    elif a < b and c != 4:
        c = b - a
    else:
        c = a + b
        a = 8
        b = 2
    for a in range(100):
        a = a + b
        c = a / 2
        if (b == c):
            b = a + c
    while c < 5:
        c = c + 2
    else:
        c = 5
    b = 1
	
def soma():
    result = a + b