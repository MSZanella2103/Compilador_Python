a = 3
b = 6 + 4 + d 
c = 5 * 5 - 5 + 8 
if(a + b == 4):
    if(b == c):
        j = "bruno"
        c = 1
    elif(b != c):
        j = "talita"
        c = 2
    else:
        j = 3
    h = 5    
elif(a - b == 3):
    c = 2
    c = 3
    c = 4
else:
    c = 3
    c = 5
t = "teste"
while(a < b):
    j = 5
    a = 2
    b = 4
for a in range(5):
    a = b
soma(a, b)
c = 2
d = "trabalho do " + "cadinho" + " de compiladores!"

def soma(a, b):
    return a + b
    
def teste():
    return "bruno"
